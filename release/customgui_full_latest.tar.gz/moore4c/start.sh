#!/bin/sh
# moore4c launcher v12 — voice coexistence mode (v12.3: wpa 配置自修复+httpd 清理修正)
# lua 保持运行(语音链: GX8002→UART→libccusdk→lua→ubus 必须它活着),
# app 在其后启动覆盖显示; 语音交互时原厂语音 UI 会短暂出现(正常反馈).
R=/data/moore4c
export LD_LIBRARY_PATH=$R/lib
export PATH=$R/bin:$PATH
# 本地中枢网关(米家 MIPS mTLS 直连, 云通道之外的本地双通道之一)
export NX5_MIPS_IP=192.168.50.227

# 单飞行锁: 并发 start.sh(看门狗/安装脚本/手动)互相打架会叠出双 app/多 httpd,
# mkdir 原子锁串行化——后到者等持锁方完成即退出, 下轮看门狗自然收敛。
LOCK=/tmp/m4c-start.lock
if mkdir "$LOCK" 2>/dev/null; then
  echo $$ > "$LOCK/pid"
else
  i=0; while [ -d "$LOCK" ] && [ $i -lt 20 ]; do sleep 1; i=$((i+1)); done
  rmdir "$LOCK" 2>/dev/null
  exit 0
fi

# WiFi glue: nl80211 驱动 + 状态栏 SSID 回退源。
# wpa 直接用 /data/wpa.conf(持久层): save_config 直写持久文件。
# 配置文件损坏(写入截断/语法错)导致 wpa 启动失败时自动修复:
#   ① 抢救完整 network={ssid=..} 块重建骨架 → 重试
#   ② 仍失败 → 重置纯骨架(WiFi 需重配, eth0/web 管理通道不受影响)
WPA_CONF=/data/wpa.conf
[ -f "$WPA_CONF" ] || printf 'ctrl_interface=/var/run/wpa_supplicant\nap_scan=1\nupdate_config=1\n' > "$WPA_CONF"

wpa_try_start() {
  wpa_supplicant -B -Dnl80211 -iwlan0 -c "$WPA_CONF" >/tmp/m4c-wpa.log 2>&1
  sleep 2
  ps | grep wpa_supplicant | grep -v grep >/dev/null 2>&1
}

if ! ps | grep wpa_supplicant | grep -v grep >/dev/null 2>&1; then
  if ! wpa_try_start; then
    cp -f "$WPA_CONF" "$WPA_CONF.bad" 2>/dev/null
    printf 'ctrl_interface=/var/run/wpa_supplicant\nap_scan=1\nupdate_config=1\n' > "$WPA_CONF"
    awk '/network[[:space:]]*=[[:space:]]*\{/{b=1;s=""} b{s=s $0 "\n"; if($0~/ssid[[:space:]]*=/)k=1; if($0~/\}/){if(k)printf "%s",s; b=0;k=0}}' "$WPA_CONF.bad" >> "$WPA_CONF"
    echo "[wifi-glue] config repaired from $WPA_CONF.bad ($(date))" >>/tmp/m4c-boot.log
    if ! wpa_try_start; then
      printf 'ctrl_interface=/var/run/wpa_supplicant\nap_scan=1\nupdate_config=1\n' > "$WPA_CONF"
      echo "[wifi-glue] salvage failed, config reset to skeleton ($(date))" >>/tmp/m4c-boot.log
      wpa_try_start
    fi
  fi
  ( sleep 3; udhcpc -i wlan0 -b -q -t 20 >/dev/null 2>&1 ) &
fi
wpa_cli -i wlan0 set update_config 1 >/dev/null 2>&1

# 清理旧实例
for n in property_service ubusd miio_agent sysservice s1e_standalone_app_konke; do
  p=$(ps | grep "$R/bin/$n" | grep -v grep | awk '{print $1}')
  [ -n "$p" ] && kill -9 $p 2>/dev/null
done
# busybox httpd 是 "busybox httpd -p 8080" 形态, $R/bin/httpd 模式匹配不到 →
# 每次 start.sh 都会叠一个实例(端口竞争/内存浪费), 必须按完整特征杀
p=$(ps | grep "busybox httpd -p 8080" | grep -v grep | awk '{print $1}')
[ -n "$p" ] && kill -9 $p 2>/dev/null

$R/bin/property_service   >/tmp/m4c-ps.log   2>&1 &
$R/bin/ubusd              >/tmp/m4c-ud.log   2>&1 &
sleep 1
LD_LIBRARY_PATH=$R/lib $R/bin/miio_agent  >/tmp/m4c-miio.log  2>&1 &
( for i in 1 2 3 4 5; do
    LD_LIBRARY_PATH=$R/lib $R/bin/sysservice -l d >>/tmp/m4c-ss.log 2>&1
    sleep 2
  done ) &
sleep 1
LD_LIBRARY_PATH=$R/lib $R/bin/s1e_standalone_app_konke >/tmp/m4c-s1e.log 2>&1 &
# httpd 同款单实例守卫(并发 start.sh 竞态时不叠加)
ps | grep "busybox httpd -p 8080" | grep -v grep >/dev/null 2>&1 || \
  $R/bin/busybox httpd -p 8080 -h /data/www >/tmp/m4c-httpd.log 2>&1 &
echo "moore4c v12.3 started (wpa config self-repair, web console on :8080)"

rmdir "$LOCK" 2>/dev/null
