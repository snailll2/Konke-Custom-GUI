#!/bin/sh
# relay.sh <channel 1|2 | gpio 63|86> <0|1>
# 每次 export 后必须配置 direction(重启后 GPIO 默认输入态, 不设方向写 value 无效)
case "$1" in
  1|63) [ -d /sys/class/gpio/gpio63 ] || echo 63 > /sys/class/gpio/export 2>/dev/null
        [ "$(cat /sys/class/gpio/gpio63/direction 2>/dev/null)" = "out" ] || echo out > /sys/class/gpio/gpio63/direction 2>/dev/null
        echo "$2" > /sys/class/gpio/gpio63/value 2>/dev/null ;;
  2|86) [ -d /sys/class/gpio/gpio86 ] || echo 86 > /sys/class/gpio/export 2>/dev/null
        [ "$(cat /sys/class/gpio/gpio86/direction 2>/dev/null)" = "out" ] || echo out > /sys/class/gpio/gpio86/direction 2>/dev/null
        echo "$2" > /sys/class/gpio/gpio86/value 2>/dev/null ;;
esac
