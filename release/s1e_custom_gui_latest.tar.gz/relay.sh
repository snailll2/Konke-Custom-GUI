#!/bin/sh
# Konke 2-gang relay backend: id1=gpio63, id2=gpio86 (active high)
case "$1" in
  1) [ -d /sys/class/gpio/gpio63 ] || echo 63 > /sys/class/gpio/export 2>/dev/null
     echo "$2" > /sys/class/gpio/gpio63/value 2>/dev/null ;;
  2) [ -d /sys/class/gpio/gpio86 ] || echo 86 > /sys/class/gpio/export 2>/dev/null
     echo "$2" > /sys/class/gpio/gpio86/value 2>/dev/null ;;
esac
exit 0
