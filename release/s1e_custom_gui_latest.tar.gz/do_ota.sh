#!/bin/sh
# Konke OTA apply: download -> verify -> install -> reboot
# Reads tarball_url/size from /tmp/remote_ver.json (fetched by the app's version check)
# 下载与暂存走 /data/moore4c/ota(持久层当临时区, 用完即删), 不占 tmpfs RAM
PROG=/tmp/ota_progress.json
OTA_DIR=/data/moore4c/ota
echo '{"status":"downloading","progress":5,"message":"正在连接固件发布仓库..."}' > $PROG

URL=$(grep -o '"tarball_url": *"[^"]*"' /tmp/remote_ver.json 2>/dev/null | head -1 | sed 's/.*"tarball_url": *"//; s/"$//')
[ -z "$URL" ] && URL="https://raw.githubusercontent.com/snailll2/Konke-Custom-GUI/main/release/s1e_custom_gui_latest.tar.gz"

# raw URL -> host + path (2026-11-13: 支持 http:// 直链 — 局域网/镜像源;
# https 走原 fetch_https.sh 链, http 用 curl 直下)
case "$URL" in
  http://*)
    H=""
    P="$URL"
    ;;
  *)
    H=$(echo "$URL" | sed 's|https://||; s|/.*||')
    P=$(echo "$URL" | sed 's|https://[^/]*||')
    ;;
esac

FREE_KB=$(df -k /data 2>/dev/null | tail -1 | awk '{print $4}')
if [ -n "$FREE_KB" ] && [ "$FREE_KB" -lt 40960 ]; then
    echo '{"status":"error","message":"/data 空间不足(<40MB), 请清理后重试"}' > $PROG
    exit 1
fi
mkdir -p $OTA_DIR
rm -f $OTA_DIR/s1e_ota_latest.tar.gz; rm -rf $OTA_DIR/staging
if [ -n "$H" ]; then
    /data/scripts/fetch_https.sh "$H" "$P" $OTA_DIR/s1e_ota_latest.tar.gz 240 &
else
    curl -skfL -m 240 "$P" -o $OTA_DIR/s1e_ota_latest.tar.gz &
fi
DL_PID=$!
TOTAL_SZ=$(grep -oE '"tarball_size_bytes": *[0-9]+' /tmp/remote_ver.json 2>/dev/null | grep -oE '[0-9]+$')
[ -z "$TOTAL_SZ" ] || [ "$TOTAL_SZ" -le 0 ] && TOTAL_SZ=3145728
TOTAL_KB=$(( TOTAL_SZ / 1024 ))
while kill -0 $DL_PID 2>/dev/null; do
    SZ=$(wc -c < $OTA_DIR/s1e_ota_latest.tar.gz 2>/dev/null || echo 0)
    PCT=$(( SZ * 70 / TOTAL_SZ + 5 )); [ $PCT -gt 75 ] && PCT=75; [ $PCT -lt 5 ] && PCT=5
    KB=$(( SZ / 1024 ))
    echo "{\"status\":\"downloading\",\"progress\":$PCT,\"message\":\"正在下载固件 ($KB KB / $TOTAL_KB KB)...\"}" > $PROG
    sleep 0.2
done
wait $DL_PID
if [ $? -ne 0 ] || [ ! -s $OTA_DIR/s1e_ota_latest.tar.gz ]; then
    echo '{"status":"error","message":"固件下载失败，请检查网络或令牌"}' > $PROG
    rm -rf $OTA_DIR
    exit 1
fi
echo '{"status":"verifying","progress":80,"message":"正在校验固件完整性..."}' > $PROG
tar -tzf $OTA_DIR/s1e_ota_latest.tar.gz >/dev/null 2>&1 || { echo '{"status":"error","message":"固件损坏或校验不通过"}' > $PROG; rm -rf $OTA_DIR; exit 1; }

echo '{"status":"installing","progress":90,"message":"正在解压安装并更新系统..."}' > $PROG
killall -9 s1e_standalone_app_konke s1e_standalone_app 2>/dev/null
mkdir -p $OTA_DIR/staging
tar -xzf $OTA_DIR/s1e_ota_latest.tar.gz -C $OTA_DIR/staging/
# 用户数据默认文件保护清单: 与包内实际存在的默认配置一一对应
for CFG in layout_p0.json sys_settings.json ha_config.json ha_cards.json switch_config.json voice_map.json; do
    [ -f "/data/scripts/$CFG" ] && rm -f "$OTA_DIR/staging/$CFG"
done
# 主题升级(仅当包内带主题时执行 — 主题已独立发布, 主包不含)
if [ -f "$OTA_DIR/staging/aqgui_theme.tgz" ]; then
  mkdir -p /usr/share && rm -rf /usr/share/.aqgui_new && mkdir -p /usr/share/.aqgui_new
  tar -xzf $OTA_DIR/staging/aqgui_theme.tgz -C /usr/share/.aqgui_new/ && {
    rm -rf /usr/share/aqgui && mv /usr/share/.aqgui_new/aqgui /usr/share/aqgui
  }
  rm -rf /usr/share/.aqgui_new; rm -f $OTA_DIR/staging/aqgui_theme.tgz; rm -f /data/scripts/aqgui_theme.tgz
fi
# 全新/结构化安装分支: 完整运行栈 + init.d 接管; 老 OTA 残留目录清理
if [ -d "$OTA_DIR/staging/moore4c" ]; then
    mkdir -p /data/moore4c/bin /data/moore4c/lib /data/moore4c/res
    cp -a $OTA_DIR/staging/moore4c/bin/. /data/moore4c/bin/ 2>/dev/null
    cp -a $OTA_DIR/staging/moore4c/lib/. /data/moore4c/lib/ 2>/dev/null
    cp -a $OTA_DIR/staging/moore4c/res/. /data/moore4c/res/ 2>/dev/null
    cp -f $OTA_DIR/staging/moore4c/start.sh /data/moore4c/start.sh
    chmod 755 /data/moore4c/start.sh
    if [ -f /etc/init.d/S90app ] && [ ! -f /etc/init.d/S20app ]; then
        cp -f /etc/init.d/S90app /data/S90app.stock; rm -f /etc/init.d/S90app
    fi
    cp -f $OTA_DIR/staging/init.d/S20app /etc/init.d/S20app 2>/dev/null
    cp -f $OTA_DIR/staging/init.d/S91moore4c /etc/init.d/S91moore4c 2>/dev/null
    chmod 755 /etc/init.d/S20app /etc/init.d/S91moore4c 2>/dev/null
fi

# 米家通用 CA(本地通道网关证书验证用, 非账号机密)
cp -f $OTA_DIR/staging/mijia_ca.cert /etc/config/intercom/mijia_ca.cert 2>/dev/null || cp -f $REL/mijia_ca.cert /etc/config/intercom/mijia_ca.cert 2>/dev/null
rm -rf /data/scripts/moore4c /data/scripts/init.d
# ★修复(2026-11-13): 不得原地 cp 覆盖正在执行的 do_ota.sh 自身 —
# cp 截断文件使 sh 的读偏移错位, 后续行解析成乱码报
# "line N: unterminated quoted string" 并中断安装(exit 2)。
# 自身改走 .new + mv 原子替换(新 inode, sh 的旧 fd 不受影响)。
for f in $OTA_DIR/staging/*; do
    case "$f" in
        */do_ota.sh)
            cp -f "$f" /data/scripts/do_ota.sh.new 2>/dev/null
            mv -f /data/scripts/do_ota.sh.new /data/scripts/do_ota.sh 2>/dev/null
            ;;
        *)
            cp -f "$f" /data/scripts/ 2>/dev/null
            ;;
    esac
done
cp -f /data/scripts/s1e_standalone_app_konke /data/moore4c/bin/ 2>/dev/null
cp -f /data/scripts/relay.sh /data/moore4c/bin/ 2>/dev/null
# web 在线副本: v12+ docroot=/data/www(start.sh)
mkdir -p /data/www/cgi-bin
cp -f /data/scripts/index.html /data/www/index.html 2>/dev/null
cp -f /data/scripts/api.cgi /data/www/cgi-bin/api.cgi 2>/dev/null
rm -rf $OTA_DIR
cp -f /tmp/remote_ver.json /data/scripts/version.json 2>/dev/null
chmod +x /data/scripts/s1e_standalone_app_konke /data/scripts/relay.sh /data/scripts/fetch_https.sh /data/scripts/http_body_strip /data/moore4c/bin/relay.sh 2>/dev/null
# cp -f 不保权限: 工具执行位就地修复(2026-11-13: http_body_strip 曾丢 +x 致 https 下载链死)
chmod +x /data/scripts/curl /data/scripts/http_body_strip /data/scripts/fetch_https.sh 2>/dev/null
echo '{"status":"rebooting","progress":100,"message":"升级完成，正在重启设备..."}' > $PROG
sync
sleep 2
reboot -f
