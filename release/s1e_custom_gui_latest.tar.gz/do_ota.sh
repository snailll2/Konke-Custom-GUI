#!/bin/sh
# Konke OTA apply: download -> verify -> install -> reboot
# Reads tarball_url/size from /tmp/remote_ver.json (fetched by the app's version check)
# 下载与暂存走 /data/moore4c/ota(持久层当临时区, 用完即删), 不占 tmpfs RAM
PROG=/tmp/ota_progress.json
OTA_DIR=/data/moore4c/ota
echo '{"status":"downloading","progress":5,"message":"正在连接固件发布仓库..."}' > $PROG

URL=$(grep -o '"tarball_url": *"[^"]*"' /tmp/remote_ver.json 2>/dev/null | head -1 | sed 's/.*"tarball_url": *"//; s/"$//')
[ -z "$URL" ] && URL="https://raw.githubusercontent.com/snailll2/Konke-Custom-GUI/main/release/s1e_custom_gui_latest.tar.gz"

# raw URL -> host + path
H=$(echo "$URL" | sed 's|https://||; s|/.*||')
P=$(echo "$URL" | sed 's|https://[^/]*||')

FREE_KB=$(df -k /data 2>/dev/null | tail -1 | awk '{print $4}')
if [ -n "$FREE_KB" ] && [ "$FREE_KB" -lt 40960 ]; then
    echo '{"status":"error","message":"/data 空间不足(<40MB), 请清理后重试"}' > $PROG
    exit 1
fi
mkdir -p $OTA_DIR
rm -f $OTA_DIR/s1e_ota_latest.tar.gz; rm -rf $OTA_DIR/staging
/data/scripts/fetch_https.sh "$H" "$P" $OTA_DIR/s1e_ota_latest.tar.gz 120 &
DL_PID=$!
TOTAL_SZ=$(grep -o '"tarball_size_bytes": *[0-9]*' /tmp/remote_ver.json 2>/dev/null | awk '{print $2}')
[ -z "$TOTAL_SZ" ] || [ "$TOTAL_SZ" -le 0 ] && TOTAL_SZ=3145728
TOTAL_KB=$(( TOTAL_SZ / 1024 ))
while kill -0 $DL_PID 2>/dev/null; do
    SZ=$(wc -c < $OTA_DIR/s1e_ota_latest.tar.gz 2>/dev/null || echo 0)
    PCT=$(( SZ * 70 / TOTAL_SZ + 5 )); [ $PCT -gt 75 ] && PCT=75; [ $PCT -lt 5 ] && PCT=5
    KB=$(( SZ / 1024 ))
    echo "{\"status\":\"downloading\",\"progress\":$PCT,\"message\":\"正在下载固件 ($KB KB / $TOTAL_KB KB)...\"}" > $PROG
    sleep 0.2
done
wait $DL_PID
if [ $? -ne 0 ] || [ ! -s $OTA_DIR/s1e_ota_latest.tar.gz ]; then
    echo '{"status":"error","message":"固件下载失败，请检查网络或令牌"}' > $PROG
    rm -rf $OTA_DIR
    exit 1
fi
echo '{"status":"verifying","progress":80,"message":"正在校验固件完整性..."}' > $PROG
tar -tzf $OTA_DIR/s1e_ota_latest.tar.gz >/dev/null 2>&1 || { echo '{"status":"error","message":"固件损坏或校验不通过"}' > $PROG; rm -rf $OTA_DIR; exit 1; }

echo '{"status":"installing","progress":90,"message":"正在解压安装并更新系统..."}' > $PROG
killall -9 s1e_standalone_app_konke s1e_standalone_app 2>/dev/null
mkdir -p $OTA_DIR/staging
tar -xzf $OTA_DIR/s1e_ota_latest.tar.gz -C $OTA_DIR/staging/
for CFG in layout_p0.json sys_settings.json ha_config.json ha_cards.json switch_config.json lock_text.json notify_history.json energy_stats.json voice_map.json tile_entities.json passwd .gesture_guide_seen; do
    [ -f "/data/scripts/$CFG" ] && rm -f "$OTA_DIR/staging/$CFG"
done
cp -f $OTA_DIR/staging/* /data/scripts/ 2>/dev/null
cp -f /data/scripts/s1e_standalone_app_konke /data/moore4c/bin/ 2>/dev/null
cp -f /data/scripts/relay.sh /data/moore4c/bin/ 2>/dev/null
# web 在线副本: v12+ docroot=/data/www(start.sh)
mkdir -p /data/www/cgi-bin
cp -f /data/scripts/index.html /data/www/index.html 2>/dev/null
cp -f /data/scripts/api.cgi /data/www/cgi-bin/api.cgi 2>/dev/null
rm -rf $OTA_DIR
cp -f /tmp/remote_ver.json /data/scripts/version.json 2>/dev/null
chmod +x /data/scripts/s1e_standalone_app_konke /data/scripts/relay.sh /data/scripts/fetch_https.sh /data/scripts/http_body_strip /data/moore4c/bin/relay.sh 2>/dev/null
echo '{"status":"rebooting","progress":100,"message":"升级完成，正在重启设备..."}' > $PROG
sync
sleep 2
reboot -f
